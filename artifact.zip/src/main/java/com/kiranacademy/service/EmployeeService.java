package com.kiranacademy.service;

import java.util.ArrayList;

import com.kiranacademy.Employee;
import com.kiranacademy.dao.EmployeeDao;

public class EmployeeService {
	public static ArrayList<Employee> fetchEmployee() throws Exception{
		ArrayList<Employee> aarl= EmployeeDao.fetchEmployee();
		return aarl;
	}

}
