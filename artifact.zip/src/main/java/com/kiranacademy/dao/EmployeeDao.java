package com.kiranacademy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.kiranacademy.Employee;
import com.kiranacademy.utility.ConnectionFactory;

public class EmployeeDao {
	public static ArrayList<Employee> fetchEmployee() throws Exception {
		Connection con = ConnectionFactory.getConnection();
		String sql = "select * from employee";
		Statement st = con.createStatement();
		ResultSet result = st.executeQuery(sql);
		ArrayList<Employee> aarl = new ArrayList<>();
		while (result.next()) {
			int id = result.getInt(1);
			String name = result.getString(2);
			String address = result.getString(3);
			Employee em = new Employee(id, name, address);
			aarl.add(em);

		}
		con.close();
		return aarl;

	}

}
