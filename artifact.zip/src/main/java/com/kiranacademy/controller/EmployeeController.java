package com.kiranacademy.controller;

import java.util.ArrayList;

import com.kiranacademy.Employee;
import com.kiranacademy.service.EmployeeService;

public class EmployeeController {
	public static ArrayList<Employee> fetchEmployee() throws Exception {
		ArrayList<Employee> aarl = EmployeeService.fetchEmployee();

		return aarl;
	}

}
