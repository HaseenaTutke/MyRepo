package com.kiranacademy;

import java.util.ArrayList;

import com.kiranacademy.controller.EmployeeController;

public class EmployeeClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<Employee> aarl=EmployeeController.fetchEmployee();
		for(Employee ee:aarl) {
			System.out.println(ee.id);
			System.out.println(ee.name);
			System.out.println(ee.address);
			
		}
		

	}

}
