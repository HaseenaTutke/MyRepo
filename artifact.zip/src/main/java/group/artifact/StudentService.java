package group.artifact;

import java.util.ArrayList;

public class StudentService {
	static ArrayList<Student> fetchStudent() throws Exception{
		ArrayList<Student>alst=StudentDao.fetchStudent();
		return alst;
	}

}
