package group.artifact;

import java.util.ArrayList;

public class StudentClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<Student> alst=StudentController.fetchStudent();
		for(Student stu:alst) {
			System.out.println(stu.id);
			System.out.println(stu.name);
			System.out.println(stu.address);
			
		}

	}

}
