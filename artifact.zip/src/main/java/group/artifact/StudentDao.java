package group.artifact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class StudentDao {
	static ArrayList<Student> fetchStudent() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "root");
		String sql="select*from student";
		Statement st=con.createStatement();
		ResultSet result=st.executeQuery(sql);
		ArrayList<Student> alst=new ArrayList<>();
		while(result.next()) {
			int id=result.getInt(1);
			String name=result.getString(2);
			String address= result.getString(3);
			Student stu=new Student(id,name,address);
			alst.add(stu);
			
		}
		con.close();
		return alst;
		
		
	}

}
