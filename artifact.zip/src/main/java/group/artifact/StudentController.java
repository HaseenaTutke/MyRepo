package group.artifact;

import java.util.ArrayList;

public class StudentController {
	static ArrayList<Student> fetchStudent() throws Exception{
		ArrayList<Student>alst=StudentService.fetchStudent();
		return alst;
	}

}
